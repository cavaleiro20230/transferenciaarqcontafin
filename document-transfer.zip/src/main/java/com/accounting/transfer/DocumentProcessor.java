package com.accounting.transfer;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class DocumentProcessor {
    private static final Logger logger = LoggerFactory.getLogger(DocumentProcessor.class);
    
    // Document type mapping based on filename patterns
    private static final Map<String, String> DOCUMENT_TYPE_PATTERNS = new HashMap<>();
    
    static {
        DOCUMENT_TYPE_PATTERNS.put("invoice", "INVOICE");
        DOCUMENT_TYPE_PATTERNS.put("receipt", "RECEIPT");
        DOCUMENT_TYPE_PATTERNS.put("statement", "STATEMENT");
        DOCUMENT_TYPE_PATTERNS.put("report", "REPORT");
        // Add more patterns as needed
    }
    
    public static String detectDocumentType(String filename) {
        String lowercaseFilename = filename.toLowerCase();
        
        for (Map.Entry<String, String> entry : DOCUMENT_TYPE_PATTERNS.entrySet()) {
            if (lowercaseFilename.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        
        return "UNKNOWN";
    }
    
    public static void logDocumentMetadata(File file) {
        try {
            String filename = file.getName();
            String documentType = detectDocumentType(filename);
            long fileSize = file.length();
            String extension = FilenameUtils.getExtension(filename);
            LocalDateTime processTime = LocalDateTime.now();
            
            logger.info("Document Metadata: Name={}, Type={}, Size={}KB, Format={}, ProcessTime={}", 
                    filename, 
                    documentType, 
                    fileSize / 1024, 
                    extension.toUpperCase(),
                    processTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            
            // Here you could also store this metadata in a database if needed
        } catch (Exception e) {
            logger.error("Error logging document metadata", e);
        }
    }
    
    public static boolean validateDocument(File file) {
        // Basic validation - file exists and is not empty
        if (!file.exists() || file.length() == 0) {
            logger.warn("Invalid document: {} (file does not exist or is empty)", file.getName());
            return false;
        }
        
        // Check if file is readable
        if (!file.canRead()) {
            logger.warn("Invalid document: {} (file is not readable)", file.getName());
            return false;
        }
        
        // Additional validation could be added here
        // For example, checking file integrity, validating PDF structure, etc.
        
        return true;
    }
}

