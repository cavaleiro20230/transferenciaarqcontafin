package com.accounting.transfer;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DocumentTransferApp {
    private static final Logger logger = LoggerFactory.getLogger(DocumentTransferApp.class);
    
    // Directories configuration - adjust these paths as needed
    private static final String SOURCE_DIR = "C:/accounting/documents";
    private static final String DESTINATION_DIR = "C:/finance/documents";
    private static final String ARCHIVE_DIR = "C:/accounting/archive";
    
    // Supported document extensions
    private static final String[] SUPPORTED_EXTENSIONS = {"pdf", "xlsx", "docx", "xml"};
    
    public static void main(String[] args) {
        try {
            // Ensure directories exist
            createDirectoriesIfNotExist();
            
            // Start file monitoring
            startFileMonitoring();
            
            // Schedule periodic batch transfer
            schedulePeriodicTransfer();
            
            logger.info("Document Transfer Application started successfully");
        } catch (Exception e) {
            logger.error("Failed to start Document Transfer Application", e);
        }
    }
    
    private static void createDirectoriesIfNotExist() throws IOException {
        Path sourceDir = Paths.get(SOURCE_DIR);
        Path destinationDir = Paths.get(DESTINATION_DIR);
        Path archiveDir = Paths.get(ARCHIVE_DIR);
        
        if (!Files.exists(sourceDir)) {
            Files.createDirectories(sourceDir);
            logger.info("Created source directory: {}", SOURCE_DIR);
        }
        
        if (!Files.exists(destinationDir)) {
            Files.createDirectories(destinationDir);
            logger.info("Created destination directory: {}", DESTINATION_DIR);
        }
        
        if (!Files.exists(archiveDir)) {
            Files.createDirectories(archiveDir);
            logger.info("Created archive directory: {}", ARCHIVE_DIR);
        }
    }
    
    private static void startFileMonitoring() throws Exception {
        // Create a FileAlterationObserver for the source directory
        FileAlterationObserver observer = new FileAlterationObserver(
                SOURCE_DIR, 
                file -> {
                    String extension = FilenameUtils.getExtension(file.getName()).toLowerCase();
                    for (String ext : SUPPORTED_EXTENSIONS) {
                        if (ext.equals(extension)) {
                            return true;
                        }
                    }
                    return false;
                }
        );
        
        // Create a listener for file events
        FileAlterationListener listener = new FileAlterationListenerAdaptor() {
            @Override
            public void onFileCreate(File file) {
                logger.info("New file detected: {}", file.getName());
                try {
                    processDocument(file);
                } catch (IOException e) {
                    logger.error("Error processing new file: {}", file.getName(), e);
                }
            }
        };
        
        // Add the listener to the observer
        observer.addListener(listener);
        
        // Create a monitor that polls the observer every 5 seconds
        FileAlterationMonitor monitor = new FileAlterationMonitor(5000);
        monitor.addObserver(observer);
        
        // Start monitoring
        monitor.start();
        logger.info("File monitoring started for directory: {}", SOURCE_DIR);
    }
    
    private static void schedulePeriodicTransfer() throws SchedulerException {
        // Define the job
        JobDetail job = JobBuilder.newJob(DocumentTransferJob.class)
                .withIdentity("transferJob", "group1")
                .build();
        
        // Define the trigger (run every day at 2 AM)
        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity("dailyTrigger", "group1")
                .withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(2, 0))
                .build();
        
        // Schedule the job
        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(job, trigger);
        
        logger.info("Scheduled periodic transfer job to run daily at 2:00 AM");
    }
    
    public static void processDocument(File file) throws IOException {
        // Generate a unique filename to avoid conflicts
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String originalName = file.getName();
        String extension = FilenameUtils.getExtension(originalName);
        String baseName = FilenameUtils.getBaseName(originalName);
        
        String newFileName = baseName + "_" + timestamp + "." + extension;
        
        // Copy to finance department
        File destFile = new File(DESTINATION_DIR, newFileName);
        FileUtils.copyFile(file, destFile);
        
        // Move original to archive
        File archiveFile = new File(ARCHIVE_DIR, newFileName);
        FileUtils.moveFile(file, archiveFile);
        
        logger.info("Processed document: {} -> {}", originalName, newFileName);
    }
    
    // Batch transfer all documents in the source directory
    public static void batchTransferDocuments() {
        try {
            File sourceDir = new File(SOURCE_DIR);
            File[] files = sourceDir.listFiles(file -> {
                String extension = FilenameUtils.getExtension(file.getName()).toLowerCase();
                for (String ext : SUPPORTED_EXTENSIONS) {
                    if (ext.equals(extension)) {
                        return true;
                    }
                }
                return false;
            });
            
            if (files != null && files.length > 0) {
                logger.info("Starting batch transfer of {} documents", files.length);
                
                for (File file : files) {
                    try {
                        processDocument(file);
                    } catch (IOException e) {
                        logger.error("Error processing file during batch transfer: {}", file.getName(), e);
                    }
                }
                
                logger.info("Batch transfer completed");
            } else {
                logger.info("No documents found for batch transfer");
            }
        } catch (Exception e) {
            logger.error("Error during batch transfer", e);
        }
    }
}

