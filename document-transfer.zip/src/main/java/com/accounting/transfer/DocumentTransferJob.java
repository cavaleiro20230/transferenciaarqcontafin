package com.accounting.transfer;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DocumentTransferJob implements Job {
    private static final Logger logger = LoggerFactory.getLogger(DocumentTransferJob.class);
    
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        logger.info("Executing scheduled document transfer job");
        try {
            DocumentTransferApp.batchTransferDocuments();
        } catch (Exception e) {
            logger.error("Error executing scheduled document transfer", e);
            throw new JobExecutionException(e);
        }
    }
}

